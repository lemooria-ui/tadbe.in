<?php
class MainFunctions
{
    
    function __construct()
    {
        // include db handler
        require_once 'sub_functions.php';
        require_once 'config.php';
        
        
        
        $this->sub = new SubFunctions();
        if (isset($_POST['orderDetails']) && !empty($_POST['orderDetails'])) {
            $raw_data = json_decode($_POST['orderDetails'], true);
            //echo '<pre>';print_r($raw_data);echo '</pre>';
        } else {
            $raw_data = json_decode(file_get_contents('php://input'), true);
            /*if(is_array($raw_data) && count($raw_data) == 1) {
            $data = $raw_data[0];
            }*/
        } //print_r($raw_data); die;
        $data         = $raw_data;
        $this->action = isset($data['action']) ? $data['action'] : '';
        $this->data   = $data;
    }
    
    public function getAction()
    {
        return $this->action;
    }
    
    
    
    public function getAllCategotyList()
    {
        // response Array
        $response = array(
            "status" => 'error',
            "result" => array()
        );
        
        $_POST  = $this->data;
        $inputs = $this->data;
        
        $error_msg = array();
        /*    if(empty($_POST['user_id'])) {
        $error_msg[] = "User id required";
        } 
        
        if(empty($_POST['shop_id'])) {
        $error_msg[] = "Shop Id required";
        }*/
        
        
        if (!empty($error_msg)) {
            $response['result'] = $error_msg;
            header('Content-Type: application/json');
            echo json_encode($response);
        } else {
            $storecategoty = $this->sub->getAllCategotyList($inputs);
            if ($storecategoty) {
                $response["status"] = 'success';
                $response["result"] = $storecategoty;
                header('Content-Type: application/json');
                echo json_encode($response);
            } else {
                $response["result"] = "Store Categoty not added. Please try again";
                header('Content-Type: application/json');
                echo json_encode($response);
            }
        }
    }
    
    
    
    public function getOTP()
    {
        // response Array
        $response = array(
            "status" => 'error',
            "result" => array()
        );
        
        $_POST  = $this->data;
        $inputs = $this->data;
        
        $error_msg = array();
        if (empty($_POST['phone'])) {
            $error_msg[] = "Phone Number required";
        }
        
        if (!empty($error_msg)) {
            $response['result'] = $error_msg;
            header('Content-Type: application/json');
            echo json_encode($response);
        } else {
            $result = $this->sub->getOTP($inputs);
            if ($result) {
                $response["status"] = 'success';
                $response["result"] = $result;
                header('Content-Type: application/json');
                echo json_encode($response);
            } else {
                $response["result"] = "OTP Not Sent. Please try again";
                header('Content-Type: application/json');
                echo json_encode($response);
            }
        }
    }
    
    
    
    public function checkOTP()
    {
        // response Array
        $response = array(
            "status" => 'error',
            "result" => array()
        );
        
        $_POST  = $this->data;
        $inputs = $this->data;
        
        $error_msg = array();
        if (empty($_POST['phone'])) {
            $error_msg[] = "Phone Number required";
        }
        if (empty($_POST['otp'])) {
            $error_msg[] = "OTP PIN required";
        }
        
        if (!empty($error_msg)) {
            $response['result'] = $error_msg;
            header('Content-Type: application/json');
            echo json_encode($response);
        } else {
            $result = $this->sub->checkOTP($inputs);
            if ($result) {
                $response["status"] = 'success';
                $response["result"] = $result;
                header('Content-Type: application/json');
                echo json_encode($response);
            } else {
                $response["result"] = "OTP Not Check. Please try again";
                header('Content-Type: application/json');
                echo json_encode($response);
            }
        }
    }
    
    
    public function getSubCategory()
    {
        // response Array
        $response = array(
            "status" => 'error',
            "result" => array()
        );
        
        $_POST  = $this->data;
        $inputs = $this->data;
        
        $error_msg = array();
        
        
        if (!empty($error_msg)) {
            $response['result'] = $error_msg;
            header('Content-Type: application/json');
            echo json_encode($response);
        } else {
            $result = $this->sub->getSubCategory($inputs);
            if ($result) {
                $response["status"] = 'success';
                $response["result"] = $result;
                header('Content-Type: application/json');
                echo json_encode($response);
            } else {
                $response["result"] = "getSubCategory. Please try again";
                header('Content-Type: application/json');
                echo json_encode($response);
            }
        }
    }
    
    public function getStore()
    {
        // response Array
        $response = array(
            "status" => 'error',
            "result" => array()
        );
        
        $_POST  = $this->data;
        $inputs = $this->data;
        
        $error_msg = array();
        
        
        if (!empty($error_msg)) {
            $response['result'] = $error_msg;
            header('Content-Type: application/json');
            echo json_encode($response);
        } else {
            $result = $this->sub->getStore($inputs);
            if ($result) {
                $response["status"] = 'success';
                $response["result"] = $result;
                header('Content-Type: application/json');
                echo json_encode($response);
            } else {
                $response["result"] = "getStore. Please try again";
                header('Content-Type: application/json');
                echo json_encode($response);
            }
        }
    }
    
    public function getProducts()
    {
        // response Array
        $response = array(
            "status" => 'error',
            "result" => array()
        );
        
        $_POST  = $this->data;
        $inputs = $this->data;
        
        $error_msg = array();
        if (empty($_POST['store_id'])) {
            $error_msg[] = "store_id required";
        }
        
         $store_id = $_POST['store_id'];
         $query_sc = "SELECT c.*, s.id,s.scid FROM storecategoty as c 
         INNER JOIN kiwi_users as s ON s.scid=c.id
         where s.id='$store_id' ";
         $result_sc = mysql_query($query_sc) or die(mysql_error());
         $row_sc = mysql_fetch_array($result_sc);
        
        
        if (!empty($error_msg)) {
            $response['result'] = $error_msg;
            header('Content-Type: application/json');
            echo json_encode($response);
        } else {
            $result = $this->sub->getProducts($inputs);
            if ($result) {
                $response["status"] = 'success';
                $response["variation"] = $row_sc['variation'];
                $response["result"] = $result;
                header('Content-Type: application/json');
                echo json_encode($response);
            } else {
                $response["result"] = "getProducts. Please try again";
                header('Content-Type: application/json');
                echo json_encode($response);
            }
        }
    }
    
    public function getProductsCategory()
    {
        // response Array
        $response = array(
            "status" => 'error',
            "result" => array()
        );
        
        $_POST  = $this->data;
        $inputs = $this->data;
        
        $error_msg = array();
        if (empty($_POST['store_id'])) {
            $error_msg[] = "store_id required";
        }
        
        
        if (!empty($error_msg)) {
            $response['result'] = $error_msg;
            header('Content-Type: application/json');
            echo json_encode($response);
        } else {
            $result             = $this->sub->getProductsCategory($inputs);
            //             if ($result) {             
            $response["status"] = 'success';
            $response["result"] = $result;
            header('Content-Type: application/json');
            echo json_encode($response);
            /*} else {
            $response["result"] = "getProducts. Please try again";
            header('Content-Type: application/json');
            echo json_encode($response);                
            }*/
        }
    }
    
    public function getProductsSubCategory()
    {
        // response Array
        $response = array(
            "status" => 'error',
            "result" => array()
        );
        
        $_POST  = $this->data;
        $inputs = $this->data;
        
        $error_msg = array();
        if (empty($_POST['store_id'])) {
            $error_msg[] = "store_id required";
        }
        
        
        if (!empty($error_msg)) {
            $response['result'] = $error_msg;
            header('Content-Type: application/json');
            echo json_encode($response);
        } else {
            $result = $this->sub->getProductsSubCategory($inputs);
            if ($result) {
                $response["status"] = 'success';
                $response["result"] = $result;
                header('Content-Type: application/json');
                echo json_encode($response);
            } else {
                $response["result"] = "getProductsSubCategory. Please try again";
                header('Content-Type: application/json');
                echo json_encode($response);
            }
        }
    }
    
    
    public function getProductsCategoryWise()
    {
        // response Array
        $response = array(
            "status" => 'error',
            "result" => array()
        );
        
        $_POST  = $this->data;
        $inputs = $this->data;
        
        $error_msg = array();
        if (empty($_POST['store_id'])) {
            $error_msg[] = "store_id required";
        }
        
        
        if (!empty($error_msg)) {
            $response['result'] = $error_msg;
            header('Content-Type: application/json');
            echo json_encode($response);
        } else {
            $result = $this->sub->getProductsCategoryWise($inputs);
            if ($result) {
                $response["status"] = 'success';
                $response["result"] = $result;
                header('Content-Type: application/json');
                echo json_encode($response);
            } else {
                $response["result"] = "getProductsCategoryWise. Please try again";
                header('Content-Type: application/json');
                echo json_encode($response);
            }
        }
    }
    
    public function getProductsSubCategoryWise()
    {
        // response Array
        $response = array(
            "status" => 'error',
            "result" => array()
        );
        
        $_POST  = $this->data;
        $inputs = $this->data;
        
        $error_msg = array();
        if (empty($_POST['store_id'])) {
            $error_msg[] = "store_id required";
        }
        
        
        if (!empty($error_msg)) {
            $response['result'] = $error_msg;
            header('Content-Type: application/json');
            echo json_encode($response);
        } else {
            $result = $this->sub->getProductsSubCategoryWise($inputs);
            if ($result) {
                $response["status"] = 'success';
                $response["result"] = $result;
                header('Content-Type: application/json');
                echo json_encode($response);
            } else {
                $response["result"] = "getProductsSubCategoryWise. Please try again";
                header('Content-Type: application/json');
                echo json_encode($response);
            }
        }
    }
    
    
    public function getBanner()
    {
        // response Array
        $response = array(
            "status" => 'error',
            "result" => array()
        );
        
        $_POST  = $this->data;
        $inputs = $this->data;
        
        $error_msg = array();
        
        
        if (!empty($error_msg)) {
            $response['result'] = $error_msg;
            header('Content-Type: application/json');
            echo json_encode($response);
        } else {
            $result = $this->sub->getBanner($inputs);
            if ($result) {
                $response["status"] = 'success';
                $response["result"] = $result;
                header('Content-Type: application/json');
                echo json_encode($response);
            } else {
                $response["result"] = "getBanner. Please try again";
                header('Content-Type: application/json');
                echo json_encode($response);
            }
        }
    }
    
    public function userUpdate()
    {
        // response Array
        $response = array(
            "status" => 'error',
            "result" => array()
        );
        
        $_POST  = $this->data;
        $inputs = $this->data;
        
        $error_msg = array();
        if (empty($_POST['id'])) {
            $error_msg[] = "id required";
        }
        
        
        
        if (!empty($error_msg)) {
            $response['result'] = $error_msg;
            header('Content-Type: application/json');
            echo json_encode($response);
        } else {
            $result = $this->sub->userUpdate($inputs);
            if ($result) {
                $response["status"] = 'success';
                $response["result"] = $result;
                header('Content-Type: application/json');
                echo json_encode($response);
            } else {
                $response["result"] = "userUpdate. Please try again";
                header('Content-Type: application/json');
                echo json_encode($response);
            }
        }
    }
    
    public function addCart()
    {
        // response Array
        $response = array(
            "status" => 'error',
            "result" => array()
        );
        
        $_POST  = $this->data;
        $inputs = $this->data;
        
        $error_msg = array();
        if (empty($_POST['product_id'])) {
            $error_msg[] = "product_id required";
        }
        if (empty($_POST['qty'])) {
            $error_msg[] = "qty required";
        }
        if (empty($_POST['weight'])) {
            $error_msg[] = "weight required";
        }
        if (empty($_POST['user_id'])) {
            $error_msg[] = "user_id required";
        }
        if (empty($_POST['cart_type'])) {
            $error_msg[] = "cart_type required";
        }
        
        
        
        if (!empty($error_msg)) {
            $response['result'] = $error_msg;
            header('Content-Type: application/json');
            echo json_encode($response);
        } else {
            $result = $this->sub->addCart($inputs);
            if ($result) {
                $response["status"] = 'success';
                $response["result"] = $result;
                header('Content-Type: application/json');
                echo json_encode($response);
            } else {
                $response["result"] = "addCart. Please try again";
                header('Content-Type: application/json');
                echo json_encode($response);
            }
        }
    }
    public function getCart()
    {
        // response Array
        $response = array(
            "status" => 'error',
            "result" => array()
        );
        
        $_POST  = $this->data;
        $inputs = $this->data;
        
        $error_msg = array();
        
        if (empty($_POST['user_id'])) {
            $error_msg[] = "user_id required";
        }
        
        
        
        if (!empty($error_msg)) {
            $response['result'] = $error_msg;
            header('Content-Type: application/json');
            echo json_encode($response);
        } else {
            $result = $this->sub->getCart($inputs);
            if ($result) {
                $response["status"] = 'success';
                $response["result"] = $result;
                header('Content-Type: application/json');
                echo json_encode($response);
            } else {
                $response["result"] = "getCart. Please try again";
                header('Content-Type: application/json');
                echo json_encode($response);
            }
        }
    }
    public function clearCart()
    {
        // response Array
        $response = array(
            "status" => 'error',
            "result" => array()
        );
        
        $_POST  = $this->data;
        $inputs = $this->data;
        
        $error_msg = array();
        
        if (empty($_POST['user_id'])) {
            $error_msg[] = "user_id required";
        }
        
        
        
        if (!empty($error_msg)) {
            $response['result'] = $error_msg;
            header('Content-Type: application/json');
            echo json_encode($response);
        } else {
            $result             = $this->sub->clearCart($inputs);
            //             if ($result) {             
            $response["status"] = 'success';
            $response["result"] = $result;
            header('Content-Type: application/json');
            echo json_encode($response);
            //             } else {
            //                 $response["result"] = "clearCart. Please try again";
            //                 header('Content-Type: application/json');
            //                 echo json_encode($response);                
            //             }            
        }
    }
    
    public function getStoreBanner()
    {
        // response Array
        $response = array(
            "status" => 'error',
            "result" => array()
        );
        
        $_POST  = $this->data;
        $inputs = $this->data;
        
        $error_msg = array();
        
        
        if (!empty($error_msg)) {
            $response['result'] = $error_msg;
            header('Content-Type: application/json');
            echo json_encode($response);
        } else {
            $result = $this->sub->getStoreBanner($inputs);
            if ($result) {
                $response["status"] = 'success';
                $response["result"] = $result;
                header('Content-Type: application/json');
                echo json_encode($response);
            } else {
                $response["result"] = "getStoreBanner. Please try again";
                header('Content-Type: application/json');
                echo json_encode($response);
            }
        }
    }
    public function insertOrder()
    {
        // response Array
        $response = array(
            "status" => 'error',
            "result" => array()
        );
        
        $_POST  = $this->data;
        $inputs = $this->data;
        
        $error_msg = array();
        if (empty($_POST['user_id'])) {
            $error_msg[] = "user_id required";
        }
        
        
        if (!empty($error_msg)) {
            $response['result'] = $error_msg;
            header('Content-Type: application/json');
            echo json_encode($response);
        } else {
            $result = $this->sub->insertOrder($inputs);
            if ($result) {
                $response["status"] = 'success';
                $response["result"] = $result;
                header('Content-Type: application/json');
                echo json_encode($response);
            } else {
                $response["result"] = "insertOrder. Please try again";
                header('Content-Type: application/json');
                echo json_encode($response);
            }
        }
    }
    public function getOrderList()
    {
        // response Array
        $response = array(
            "status" => 'error',
            "result" => array()
        );
        
        $_POST  = $this->data;
        $inputs = $this->data;
        
        $error_msg = array();
        if (empty($_POST['user_id'])) {
            $error_msg[] = "user_id required";
        }
        
        
        if (!empty($error_msg)) {
            $response['result'] = $error_msg;
            header('Content-Type: application/json');
            echo json_encode($response);
        } else {
            $result = $this->sub->getOrderList($inputs);
            if ($result) {
                $response["status"] = 'success';
                $response["result"] = $result;
                header('Content-Type: application/json');
                echo json_encode($response);
            } else {
                $response["result"] = "getOrderList. Please try again";
                header('Content-Type: application/json');
                echo json_encode($response);
            }
        }
    }
    public function updateOrder()
    {
        // response Array
        $response = array(
            "status" => 'error',
            "result" => array()
        );
        
        $_POST  = $this->data;
        $inputs = $this->data;
        
        $error_msg = array();
        if (empty($_POST['user_id'])) {
            $error_msg[] = "user_id required";
        }
        
        
        if (!empty($error_msg)) {
            $response['result'] = $error_msg;
            header('Content-Type: application/json');
            echo json_encode($response);
        } else {
            $result = $this->sub->updateOrder($inputs);
            if ($result) {
                $response["status"] = 'success';
                $response["result"] = $result;
                header('Content-Type: application/json');
                echo json_encode($response);
            } else {
                $response["result"] = "updateOrder. Please try again";
                header('Content-Type: application/json');
                echo json_encode($response);
            }
        }
    }
    public function insertReview()
    {
        // response Array
        $response = array(
            "status" => 'error',
            "result" => array()
        );
        
        $_POST  = $this->data;
        $inputs = $this->data;
        
        $error_msg = array();
        if (empty($_POST['user_id'])) {
            $error_msg[] = "user_id required";
        }
        if (empty($_POST['store_id'])) {
            $error_msg[] = "store_id required";
        }
        
        
        if (!empty($error_msg)) {
            $response['result'] = $error_msg;
            header('Content-Type: application/json');
            echo json_encode($response);
        } else {
            $result = $this->sub->insertReview($inputs);
            if ($result) {
                $response["status"] = 'success';
                $response["result"] = $result;
                header('Content-Type: application/json');
                echo json_encode($response);
            } else {
                $response["result"] = "insertReview. Please try again";
                header('Content-Type: application/json');
                echo json_encode($response);
            }
        }
    }
    public function getOrderDetailsById()
    {
        // response Array
        $response = array(
            "status" => 'error',
            "result" => array()
        );
        
        $_POST  = $this->data;
        $inputs = $this->data;
        
        $error_msg = array();
        if (empty($_POST['user_id'])) {
            $error_msg[] = "user_id required";
        }
        if (empty($_POST['id'])) {
            $error_msg[] = "id required";
        }
        
        
        if (!empty($error_msg)) {
            $response['result'] = $error_msg;
            header('Content-Type: application/json');
            echo json_encode($response);
        } else {
            $result = $this->sub->getOrderDetailsById($inputs);
            if ($result) {
                $response["status"] = 'success';
                $response["result"] = $result;
                header('Content-Type: application/json');
                echo json_encode($response);
            } else {
                $response["result"] = "getOrderDetailsById. Please try again";
                header('Content-Type: application/json');
                echo json_encode($response);
            }
        }
    }
    public function getZipcode()
    {
        // response Array
        $response = array(
            "status" => 'error',
            "result" => array()
        );
        
        $_POST  = $this->data;
        $inputs = $this->data;
        
        $error_msg = array();
       
       
        
        
        if (!empty($error_msg)) {
            $response['result'] = $error_msg;
            header('Content-Type: application/json');
            echo json_encode($response);
        } else {
            $result = $this->sub->getZipcode($inputs);
            if ($result) {
                $response["status"] = 'success';
                $response["result"] = $result;
                header('Content-Type: application/json');
                echo json_encode($response);
            } else {
                $response["status"] = 'success';
                $response["result"] = array();
                header('Content-Type: application/json');
                echo json_encode($response);
            }
        }
    }
    
    
    
}

$main_functions = New MainFunctions();
$action         = $main_functions->getAction();
//echo $action;exit;
if ($action == '') {
    // response Array
    $response = array(
        "status" => 'error',
        "result" => array(
            "Invalid action"
        )
    );
    header('Content-Type: application/json');
    echo json_encode($response);
} else {
    if (isset($action) && $action == 'get_all_category_list') {
        $main_functions->getAllCategotyList();
    } else if (isset($action) && $action == 'get_otp') {
        $main_functions->getOTP();
    } else if (isset($action) && $action == 'check_otp') {
        $main_functions->checkOTP();
    } else if (isset($action) && $action == 'get_sub_category') {
        $main_functions->getSubCategory();
    } else if (isset($action) && $action == 'get_store') {
        $main_functions->getStore();
    } else if (isset($action) && $action == 'get_products') {
        $main_functions->getProducts();
    } else if (isset($action) && $action == 'get_products_category') {
        $main_functions->getProductsCategory();
    } else if (isset($action) && $action == 'get_products_sub_category') {
        $main_functions->getProductsSubCategory();
    } else if (isset($action) && $action == 'get_products_category_wise') {
        $main_functions->getProductsCategoryWise();
    } else if (isset($action) && $action == 'get_products_sub_category_wise') {
        $main_functions->getProductsSubCategoryWise();
    } else if (isset($action) && $action == 'get_banner') {
        $main_functions->getBanner();
    } else if (isset($action) && $action == 'user_update') {
        $main_functions->userUpdate();
    } else if (isset($action) && $action == 'add_cart') {
        $main_functions->addCart();
    } else if (isset($action) && $action == 'get_cart') {
        $main_functions->getCart();
    } else if (isset($action) && $action == 'clear_cart') {
        $main_functions->clearCart();
    } else if (isset($action) && $action == 'get_store_banner') {
        $main_functions->getStoreBanner();
    } else if (isset($action) && $action == 'insert_order') {
        $main_functions->insertOrder();
    } else if (isset($action) && $action == 'get_order_list') {
        $main_functions->getOrderList();
    } else if (isset($action) && $action == 'update_order') {
        $main_functions->updateOrder();
    } else if (isset($action) && $action == 'insert_review') {
        $main_functions->insertReview();
    } else if (isset($action) && $action == 'get_order_details_by_id') {
        $main_functions->getOrderDetailsById();
    } else if (isset($action) && $action == 'get_zipcode') {
        $main_functions->getZipcode();
    
    } else {
        $response = array(
            "status" => 'error',
            "result" => array(
                "Invalid action"
            )
        );
        header('Content-Type: application/json');
        echo json_encode($response);
    }
}
?>