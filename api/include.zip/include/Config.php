<?php
 ob_start();
error_reporting(0);
define("DB_HOST", "localhost:3306");
define("DB_USER", "orangemenshostel_multiuser");
define("DB_PASSWORD", "multi123@#$");
define("DB_DATABASE", "orangemenshostel_multiadmin");

?>